@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.kenleros.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Night = Color(0xFF050912)
private val Blue = Color(0xFF168BFF)
private val Muted = Color(0xFF9BB6D5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5, 9, 18)
        window.navigationBarColor = android.graphics.Color.rgb(5, 9, 18)
        window.decorView.systemUiVisibility = 0
        setContent { KenlerosHome() }
    }
}

data class LaunchApp(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

@Composable
fun KenlerosHome() {
    val context = LocalContext.current
    var now by remember { mutableStateOf(Date()) }
    var dockOpen by remember { mutableStateOf(false) }
    var drawerOpen by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf("Главная") }

    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(1000)
        }
    }

    val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
    val date = SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(now)
        .replaceFirstChar { it.uppercase() }

    val apps = remember {
        context.packageManager.getInstalledApplications(0)
            .filter { context.packageManager.getLaunchIntentForPackage(it.packageName) != null }
            .map {
                LaunchApp(
                    context.packageManager.getApplicationLabel(it).toString(),
                    it.packageName,
                    context.packageManager.getApplicationIcon(it)
                )
            }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF071426), Night, Color.Black))
        )
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("♛  K E N L E R O S", color = Muted, fontSize = 13.sp, letterSpacing = 3.sp)
                Text("●  ●  ▰", color = Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(26.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(vertical = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(time, color = Color.White, fontSize = 66.sp, fontWeight = FontWeight.Light, letterSpacing = 1.sp)
                    Text(date, color = Muted, fontSize = 15.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("KENLEROS  •  PREMIUM LIQUID GLASS", color = Blue, fontSize = 10.sp, letterSpacing = 1.5.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GlassCard(Modifier.weight(1f)) {
                    Column(Modifier.padding(14.dp)) {
                        Icon(Icons.Default.BatteryChargingFull, null, tint = Blue)
                        Text("Устройство", color = Muted, fontSize = 12.sp)
                        Text("Galaxy A72", color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                }
                GlassCard(Modifier.weight(1f)) {
                    Column(Modifier.padding(14.dp)) {
                        Icon(Icons.Default.Widgets, null, tint = Blue)
                        Text("Интерфейс", color = Muted, fontSize = 12.sp)
                        Text("Liquid Glass", color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Избранное", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text("Все приложения", color = Muted, fontSize = 12.sp, modifier = Modifier.clickable { drawerOpen = true })
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                listOf("Телефон" to Icons.Default.Call, "Сообщения" to Icons.Default.Chat, "Камера" to Icons.Default.CameraAlt, "Настройки" to Icons.Default.Settings).forEach { (label, icon) ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable {
                        if (label == "Настройки") {
                            val i = Intent(android.provider.Settings.ACTION_SETTINGS)
                            context.startActivity(i)
                        } else {
                            val match = apps.firstOrNull { it.label.contains(label, true) }
                            match?.let { context.startActivity(context.packageManager.getLaunchIntentForPackage(it.packageName)) }
                        }
                    }) {
                        Box(Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(Color(0xFF183B60), Color(0xFF0A1424)))), contentAlignment = Alignment.Center) {
                            Icon(icon, null, tint = Color(0xFFD7E9FF), modifier = Modifier.size(26.dp))
                        }
                        Spacer(Modifier.height(5.dp))
                        Text(label, color = Muted, fontSize = 10.sp)
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            GlassCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    DockItem("Чаты", Icons.Default.ChatBubbleOutline) { selected = "Чаты" }
                    DockItem("Обзор", Icons.Default.Explore) { selected = "Обзор" }
                    Box(Modifier.size(54.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF2AA0FF), Color(0xFF082B55)))).clickable { dockOpen = true }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Add, null, tint = Color.White, modifier = Modifier.size(32.dp))
                    }
                    DockItem("GeeksOS", Icons.Default.Layers) { selected = "GeeksOS" }
                    DockItem("Профиль", Icons.Default.Person) { selected = "Профиль" }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("KENLEROS  •  ${selected.uppercase(Locale.getDefault())}", color = Color(0xFF55799F), fontSize = 9.sp, letterSpacing = 2.sp)
        }

        if (dockOpen) {
            ModalBottomSheet(
                onDismissRequest = { dockOpen = false },
                containerColor = Color(0xFF0A1728),
                contentColor = Color.White
            ) {
                Text("KENLEROS LIQUID DOCK", color = Blue, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, letterSpacing = 2.sp)
                listOf("Приложения", "Поиск", "Виджеты", "GeeksOS", "Настройки").forEach { item ->
                    ListItem(
                        headlineContent = { Text(item, color = Color.White) },
                        leadingContent = { Icon(Icons.Default.Circle, null, tint = Blue) },
                        modifier = Modifier.clickable {
                            dockOpen = false
                            if (item == "Приложения") drawerOpen = true
                            if (item == "Настройки") context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                            selected = item
                        }
                    )
                }
                Spacer(Modifier.height(24.dp))
            }
        }

        if (drawerOpen) {
            AlertDialog(
                onDismissRequest = { drawerOpen = false },
                title = { Text("Приложения") },
                text = {
                    LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.heightIn(max = 430.dp)) {
                        items(apps.take(90)) { app ->
                            Column(
                                Modifier.fillMaxWidth().clickable {
                                    drawerOpen = false
                                    context.startActivity(context.packageManager.getLaunchIntentForPackage(app.packageName))
                                }.padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                AndroidAppIcon(app.icon)
                                Text(app.label, fontSize = 10.sp, maxLines = 2, textAlign = TextAlign.Center)
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { drawerOpen = false }) { Text("Закрыть") } }
            )
        }
    }
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(Color(0xCC18304C), Color(0xAA091321), Color(0xCC102B49))))
            .padding(1.dp)
            .background(Color(0xB908101C), RoundedCornerShape(25.dp)),
        content = content
    )
}

@Composable
fun DockItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onClick() }) {
        Icon(icon, null, tint = Color(0xFFBBD9FA), modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = Muted, fontSize = 9.sp)
    }
}

@Composable
fun AndroidAppIcon(icon: android.graphics.drawable.Drawable) {
    androidx.compose.ui.viewinterop.AndroidView(
        factory = { context ->
            android.widget.ImageView(context).apply {
                setImageDrawable(icon)
                scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            }
        },
        modifier = Modifier.size(42.dp)
    )
}
